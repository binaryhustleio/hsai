# 🧱 Defense Lab

(coming soon) You’ll set up Fail2Ban, observe logs, and write block rules based on traffic patterns.

# 📊 Logs & Observability

Grafana is available on port `3001`.

You can add Loki as a data source and explore logs from simulated attacks or NGINX traces.

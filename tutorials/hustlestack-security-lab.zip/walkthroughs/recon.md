# 🕵️ Recon Lab

Use `nmap` to scan the DVWA and Juice Shop apps in this lab.

```bash
docker exec -it $(docker ps -qf ancestor=instrumentisto/nmap) nmap dvwa
docker exec -it $(docker ps -qf ancestor=instrumentisto/nmap) nmap juice-shop
```

# 🛡️ HustleStack.Security Beginner Cyber Lab

This lab is a plug-and-play Docker Compose stack designed to teach cybersecurity fundamentals through real-world open-source tools.

## 🚀 How to Start

1. Unzip this folder
2. Run: `docker compose up -d`
3. Follow walkthroughs in `/walkthroughs` to start learning

---

## Included Tools

| Tool        | Description                         |
|-------------|-------------------------------------|
| Nmap        | Network scanning and recon          |
| Juice Shop  | Vulnerable web app for practice     |
| DVWA        | Damn Vulnerable Web App             |
| Metasploit  | Exploit framework                   |
| Grafana     | Visualize logs                      |
| Loki        | Log aggregation for observability   |
